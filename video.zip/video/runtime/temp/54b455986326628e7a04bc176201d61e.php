<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:92:"C:\phpStudy\PHPTutorial\WWW\iqiyiTP5\video\public/../application/admins\view\home\index.html";i:1524637992;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<title>管理中心</title>
	<link rel="stylesheet" type="text/css" href="../../../static/plugins/layui/css/layui.css">
	<script type="text/javascript" src="../../../static/plugins/layui/layui.js"></script>
	<style type="text/css">
		.header{width: 100%;height: 50px;line-height: 50px;background: #2e6da4;color: #fff;}
		.title{margin-left: 20px;font-size: 20px;}
		.userinfo{float:right;margin-right: 20px;}
		.userinfo a{color:#fff;}
		.menu{width:200px;background:#333774;position:absolute;}
		.main{position:absolute; left: 200px;width: 88%;}

		.layui-collapse{border:none;}
		.layui-colla-title{background: #42485b;color: #fff;}
		.layui-colla-content{padding:0;border: none;}
		.layui-colla-item{border:none;}
	</style>
</head>
<body>
	<!-- header -->
	<div class="header">
		<span class="title">后台管理系统</span>
		<span class="userinfo">admin【系统管理员】<span><a href="javascript:;">退出</a></span></span>
	</div>
	<!-- 菜单 -->
	<div class="menu" id="menu">
	<div class="layui-collapse" lay-accordion>
		<div class="layui-colla-item">
		    <h2 class="layui-colla-title">管理员管理</h2>
		    <div class="layui-colla-content layui-show">
		    	<ul class="layui-nav layui-nav-tree" lay-filter="test">
				<!-- 侧边导航: <ul class="layui-nav layui-nav-tree layui-nav-side"> -->
				  <li class="layui-nav-item"><a href="javascript:;" onclick="menuFire(this)" src="/admins.php/admins/Admin/index">管理员列表</a></li>
				</ul>
			</div>
		  </div>
		  <div class="layui-colla-item">
		    <h2 class="layui-colla-title">权限管理</h2>
		    <div class="layui-colla-content">
				<ul class="layui-nav layui-nav-tree" lay-filter="test">
				  <li class="layui-nav-item"><a href="javascript:;" onclick="menuFire(this)" src="/admins.php/admins/Menu/index">菜单管理</a></li>
				  <li class="layui-nav-item"><a href="javascript:;" onclick="menuFire(this)" src="/admins.php/admins/Roles/index">角色管理</a></li>
				</ul>
		    </div>
		  </div>
		  <div class="layui-colla-item">
		    <h2 class="layui-colla-title">系统设置</h2>
		    <div class="layui-colla-content">内容区域</div>
		  </div>
		</div>
	</div>
	<!-- 主操作页面 -->
	<div class="main">
		<iframe src="/admins.php/admins/Home/welcome" onload="resetMainHeight(this)" style="width:100%; height:100%; " frameborder="0" scrolling="0" ></iframe>
	</div>

<script>
	layui.use('element', function(){
	  var element = layui.element;
	  $ = layui.jquery;
	  resetMenuHeight();
	});
	//重新设置菜单容器高度
	function resetMenuHeight(){
		var height = document.documentElement.clientHeight - 50;
		$('#menu').height(height);
	}
	//重新设置主操作页面高度
	function resetMainHeight(obj){
		var height = document.documentElement.clientHeight - 53;
		$(obj).parent('div').height(height);
	}
	//菜单点击
	function menuFire(obj){
		//获取url
		var src = $(obj).attr('src');
		//设置iframe的src
		$('iframe').attr('src',src);
	}
</script>
</body>
</html>