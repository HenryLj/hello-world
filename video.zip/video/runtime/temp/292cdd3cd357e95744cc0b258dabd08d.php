<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:92:"C:\phpStudy\PHPTutorial\WWW\iqiyiTP5\video\public/../application/admins\view\menu\index.html";i:1524639927;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<title>菜单管理</title>
	<link rel="stylesheet" type="text/css" href="/static/plugins/layui/css/layui.css">
	<script type="text/javascript" src="/static/plugins/layui/layui.js"></script>
	<style type="text/css">
		.header span{background: #009688;margin-left: 30px;padding: 10px;color: #fff}
		.header div{border-bottom: 2px solid #009688; margin-top:9px;}
		.header button{float:right;}
		td{text-align: center;}
	</style>
</head>
<body style="padding:10px;">
	<div class="header">
		<span>管理员列表</span>
		<div></div>
	</div>
	<form class="layui-form">
	<input type="hidden" name="pid" value="<?php echo $pid; ?>">
	<table class="layui-table">
		<thead>
			<tr>
				<th style="text-align: center;">ID</th>
				<th style="text-align: center;">排序</th>
				<th style="text-align: center;">菜单名称</th>
				<th style="text-align: center;">controller</th>
				<th style="text-align: center;">method</th>
				<th style="text-align: center;">是否隐藏</th>
				<th style="text-align: center;">是否禁用</th>
				<th style="text-align: center;"></th>
			</tr>
		</thead>
		<tbody>
			<?php if(is_array($data['lists']) || $data['lists'] instanceof \think\Collection || $data['lists'] instanceof \think\Paginator): $i = 0; $__LIST__ = $data['lists'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
			<tr>
				<td><?php echo $vo['mid']; ?></td>
				<td><input type="text" class="layui-input" name="ords[<?php echo $vo['mid']; ?>]" value="<?php echo $vo['ord']; ?>" /></td>
				<td><input type="text" class="layui-input" name="titles[<?php echo $vo['mid']; ?>]" value="<?php echo $vo['title']; ?>" /></td>
				<td><input type="text" class="layui-input" name="controllers[<?php echo $vo['mid']; ?>]" value="<?php echo $vo['controller']; ?>" /></td>
				<td><input type="text" class="layui-input" name="methods[<?php echo $vo['mid']; ?>]" value="<?php echo $vo['method']; ?>" /></td>
				<td><input type="checkbox" lay-skin="primary" name="ishiddens[<?php echo $vo['mid']; ?>]" title="隐藏" <?php echo !empty($vo['ishidden'])?'checked':''; ?> value=1 /></td>
				<td><input type="checkbox" lay-skin="primary" name="status[<?php echo $vo['mid']; ?>]" title="禁用" <?php echo !empty($vo['status'])?'checked':''; ?> value=1 /></td>
				<td>
				<button class="layui-btn layui-btn-xs" onclick="child(<?php echo $vo['mid']; ?>);return false;">子菜单</button>
				<?php if($pid>0): ?>
				<input type="button" class="layui-btn layui-btn-xs" onclick="black(<?php echo $backid; ?>);" value="返回上一级" />
				<?php endif; ?>
				</td>
			</tr>
			<?php endforeach; endif; else: echo "" ;endif; ?>
				<tr>
				<td>添加</td>
				<td><input type="text" class="layui-input" name="ords[0]" /></td>
				<td><input type="text" class="layui-input" name="titles[0]" /></td>
				<td><input type="text" class="layui-input" name="controllers[0]" /></td>
				<td><input type="text" class="layui-input" name="methods[0]" /></td>
				<td><input type="checkbox" lay-skin="primary" name="ishiddens[0]" title="隐藏" value=1 /></td>
				<td><input type="checkbox" lay-skin="primary" name="status[0]" title="禁用" value=1 /></td>
				<td>
				</td>
			</tr>			
		</tbody>
	</table>
	<input type="button" class="layui-btn" onclick="save();" value="保存" />
	</form>
	<script type="text/javascript">
		layui.use(['layer','form'],function(){
			layer = layui.layer;
			form = layui.form;
			$ = layui.jquery;
		})
		//子菜单
		function child(pid){
			window.location.href="/admins.php/admins/Menu/index?pid="+pid;
		}
		//返回上一级
		function black(pid){
			window.location.href="/admins.php/admins/Menu/index?pid="+pid;
		}
		//保存数据
		function save(){
			$.post('/admins.php/admins/Menu/save',$('form').serialize(),function(res){
				if(res.code>0){
					layer.alert(res.msg,{'icon':2});
				}else{
					layer.msg(res.msg,{'icon':1});
					setTimeout(function(){window.location.reload();},1000);
				}
			},'json');
		}
	</script>
</body>
</html>