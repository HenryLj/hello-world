<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:91:"C:\phpStudy\PHPTutorial\WWW\iqiyiTP5\video\public/../application/admins\view\roles\add.html";i:1524646006;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<title>添加角色</title>
	<link rel="stylesheet" type="text/css" href="/static/plugins/layui/css/layui.css">
	<script type="text/javascript" src="/static/plugins/layui/layui.js"></script>
	<style type="text/css">
		.header span{background: #009688;margin-left: 30px;padding: 10px;color: #fff}
		.header div{border-bottom: 2px solid #009688; margin-top:9px;}
		.header button{float:right;}
		td{text-align: center;}
	</style>
</head>
<body style="padding:10px;">
	<form class="layui-form">
		<input type="hidden" name="gid" value="<?php echo $role['gid']; ?>">
		<div class="layui-form-item">
			<label class="layui-form-label">角色名称</label>
			<div class="layui-input-inline">
				<input type="text" class="layui-input" name="title" value="<?php echo $role['title']; ?>" />
			</div>
		</div>

		<div class="layui-form-item">
			<label class="layui-form-label">权限菜单</label>
			<?php if(is_array($menus) || $menus instanceof \think\Collection || $menus instanceof \think\Paginator): $i = 0; $__LIST__ = $menus;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
			<div class="layui-input-block">
				<input type="checkbox" lay-skin="primary" name="menu[<?php echo $vo['mid']; ?>]" title="<?php echo $vo['title']; ?>" <?php echo isset($role['rights']) && $role['rights'] && in_array($vo['mid'],$role['rights'])?'checked':''; ?> />
				<hr/>
				<?php if(is_array($vo['children']) || $vo['children'] instanceof \think\Collection || $vo['children'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['children'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$cvo): $mod = ($i % 2 );++$i;?>
				<input type="checkbox" name="menu[<?php echo $cvo['mid']; ?>]" lay-skin="primary" title="<?php echo $cvo['title']; ?>" <?php echo isset($role['rights']) && $role['rights'] && in_array($cvo['mid'],$role['rights'])?'checked':''; ?> />
				<?php endforeach; endif; else: echo "" ;endif; ?>
			</div>
			<?php endforeach; endif; else: echo "" ;endif; ?>
		</div>
	</form>
	<div class="layui-form-item">
		<div class="layui-input-block">
			<input type="button" class="layui-btn" name="" value="保存" onclick="save()" />
		</div>
	</div>
	<script type="text/javascript">
		layui.use(['layer','form'],function(){
			$ = layui.jquery;
			layer = layui.layer;
			form = layui.form;
		})
		//保存角色
		function save(){
			var title = $.trim($('input[name="title"]').val());
			if(title==''){
				layer.msg('请填写角色名称',{icon:2});
				return;
			}
			$.post('/admins.php/admins/Roles/save',$('form').serialize(),function(res){
				if(res.code>0){
					layer.alert(res.msg,{'icon':2});
				}else{
					layer.msg(res.msg,{'icon':1});
					setTimeout(function(){parent.window.location.reload();},1000);
				}
			},'json');
		}
	</script>
</body>
</html>