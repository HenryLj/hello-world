<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:94:"C:\phpStudy\PHPTutorial\WWW\iqiyiTP5\video\public/../application/admins\view\home\welcome.html";i:1520818491;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div style="text-align:center;color:gray;font-size:20px;">
		<h1>欢迎使用后台管理系统</h1>
	</div>
</body>
</html>